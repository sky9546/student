package com.login.studentManagement.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.login.studentManagement.modal.admin;
import com.login.studentManagement.modal.UserDtls;

public interface AdminService {
	List<admin> getAllEmployees();
	void saveEmployee(admin employee);
	admin getEmployeeById(long id);
	void deleteEmployeeById(long id);
	Page<admin> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);

	public UserDtls createUser(UserDtls user);

	public boolean checkEmail(String email);
	Object findAll();

}
