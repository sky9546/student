package com.login.studentManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.login.studentManagement.modal.admin;

@Repository
public interface AdminRepository extends JpaRepository<admin, Long>{



}

