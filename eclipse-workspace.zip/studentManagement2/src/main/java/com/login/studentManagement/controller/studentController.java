package com.login.studentManagement.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/student")


public class studentController {

	@GetMapping("/")
	public String admin() {
		return "student/home";
		
		
	}


}


