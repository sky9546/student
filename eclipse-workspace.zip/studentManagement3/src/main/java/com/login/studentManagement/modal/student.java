package com.login.studentManagement.modal;

public class student {

}
