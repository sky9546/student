package com.login.studentManagement.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.login.studentManagement.modal.CourseDetails;
import com.login.studentManagement.modal.UserDtls;
import com.login.studentManagement.service.AdminService;
import com.login.studentManagement.service.UserService;

@Controller
public class MainController {

	@Autowired
	private AdminService employeeService;
	@Autowired
private UserService userService;

	@GetMapping({"/list"})
	public ModelAndView getAllEmployees() {
		ModelAndView mav = new ModelAndView("list-courses");
		mav.addObject("courses", employeeService.findAll());
		return mav;
	}
	
	@PostMapping("/saveCourse")
	public String saveEmployee(@ModelAttribute("course") CourseDetails course) {
		// save employee to database
		employeeService.saveEmployee(course);
		return "redirect:/list";
		
	}
	@GetMapping("/showNewEmployeeForm")
	public String showNewEmployeeForm(Model model) {
		// create model attribute to bind form data
		CourseDetails course = new CourseDetails();
		model.addAttribute("CourseDetails", course);
		return "new_employee";
	}

//	@GetMapping("/")
//	public String index() {
//		return "index";
//	}
//
	@GetMapping("/signin")
	public String login() {
		return "login";
	}
	

	@GetMapping("/home")
	public String home1() {
		return "homepage";
	}
	@GetMapping("/register")
	public String register() {
		return "register";
	}

	@PostMapping("/createUser")
	public String createuser(@ModelAttribute UserDtls employee, HttpSession session) {
		

		// System.out.println(user);

		boolean f = userService.checkEmail(employee.getEmail());

		if (f) {
			session.setAttribute("msg", "Email Id alreday exists");
		}

		else {
			UserDtls userDtls = userService.createUser(employee);
			if (userDtls != null) {
				session.setAttribute("msg", "Register Sucessfully");
			} else {
				session.setAttribute("msg", "Something wrong on server");
			}
		}

		return "redirect:/register";
	}

	


	

}
