package com.login.studentManagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.login.studentManagement.modal.CourseDetails;
import com.login.studentManagement.modal.UserDtls;
import com.login.studentManagement.repository.AdminRepository;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminRepository employeeRepository;


	
	@Override
	public UserDtls createUser(UserDtls user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkEmail(String email) {
		// TODO Auto-generated method stub
		return false;
	}
//new
	@Override
	public Object findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CourseDetails saveEmployee(CourseDetails course) {
		return course;
		// TODO Auto-generated method stub
		
	}



}
