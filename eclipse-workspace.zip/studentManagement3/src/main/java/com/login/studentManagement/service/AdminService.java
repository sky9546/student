package com.login.studentManagement.service;

import com.login.studentManagement.modal.CourseDetails;
import com.login.studentManagement.modal.UserDtls;

public interface AdminService {
	
	public UserDtls createUser(UserDtls user);

	public boolean checkEmail(String email);
	Object findAll();

	public CourseDetails saveEmployee(CourseDetails course);

}
