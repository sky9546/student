package com.login.studentManagement.modal;



import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity // This tells Hibernate to make a table out of this class
public class CourseDetails {
  @Id
  @GeneratedValue(strategy=GenerationType.AUTO)
  private Integer id;

 private String Course_name;
 private String CourseDetails;
 private Date date;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getCourse_name() {
	return Course_name;
}
public void setCourse_name(String course_name) {
	Course_name = course_name;
}
public String getCourseDetails() {
	return CourseDetails;
}
public void setCourseDetails(String courseDetails) {
	CourseDetails = courseDetails;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
 
}