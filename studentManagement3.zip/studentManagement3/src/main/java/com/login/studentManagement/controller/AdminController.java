package com.login.studentManagement.controller;

import java.security.Principal;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.login.studentManagement.modal.UserDtls;
import com.login.studentManagement.modal.courseDetails;
import com.login.studentManagement.repository.UserRepository;
import com.login.studentManagement.service.CourseService;
import com.login.studentManagement.service.UserService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	CourseService courseservice ;
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private UserService userService;

	
	@ModelAttribute
	private void userDetails(Model m, Principal p) {
		String email = p.getName();
		UserDtls user = userRepo.findByEmail(email);

		m.addAttribute("user", user);

	}
	@GetMapping("/")
	public String home(Model model) {
	
		model.addAttribute("signedin", true);
		model.addAttribute("isadmin", true);
		System.out.println(courseservice.getCourse().size());
		
		model.addAttribute("courseList", courseservice.getCourse());
		
		
		
		
		return "admin1/home";
	}
	
	@GetMapping("addCourse")
	public String addCoursepage(Model model) {
		model.addAttribute("isadmin", true);
		model.addAttribute("signedin", true);
		return "admin1/addCourse";
	
		
	}
	

	@GetMapping("/login")
	public String redirection2(Model model) {
		
		return "loginAdmin";
	
		
	}
	
	
	@PostMapping("Course")
	public String addCourse(@ModelAttribute courseDetails course, HttpSession session,Model model1) {
		model1.addAttribute("isadmin", true);
		model1.addAttribute("signedin", true);
		ModelAndView model = new ModelAndView() ;
		
		model.addObject("course", courseservice.createCourse(course));

		
		return "redirect:/admin/";
		
	}

	
	@GetMapping("/register")
	public String redirection() {
		return "admin1/register";
	}
	
	@PostMapping("/registeradmin")
	public String addadmin(@ModelAttribute UserDtls user, HttpSession session,Model model1) {

		

		boolean f = userService.checkEmail(user.getEmail());

		if (f) {
			session.setAttribute("msg", "Email Id alreday exists");
		}

		else {
			UserDtls userDtls = userService.createadminUser(user);
			if (userDtls != null) {
				session.setAttribute("msg", "Register Sucessfully");
			} else {
				session.setAttribute("msg", "Something wrong on server");
			}
		}


		
		return "redirect:/register";
		
	}
	
	
}