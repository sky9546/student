package com.login.studentManagement.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.login.studentManagement.modal.UserDtls;
import com.login.studentManagement.modal.courseDetails;
import com.login.studentManagement.repository.CourseRepository;
import com.login.studentManagement.repository.UserRepository;

@Service
public class CourseServiceimpl implements CourseService {

	@Autowired
	private CourseRepository CourseRepo;

//	@Autowired
//	private BCryptPasswordEncoder passwordEncode;

//	@Override
//	public UserDtls createUser(UserDtls user) {
//
//		user.setPassword(passwordEncode.encode(user.getPassword()));
//		user.setRole("ROLE_USER");
//
//		return userRepo.save(user);
//	}
//
//	@Override
//	public boolean checkEmail(String email) {
//
//		return userRepo.existsByEmail(email);
//	}

	@Override
	public courseDetails createCourse(courseDetails course) {
		
		
		
		return CourseRepo.save(course)  ;
	}

	@Override
	public List<courseDetails> getCourse() {
		// TODO Auto-generated method stub
		return CourseRepo.findAll() ;
	}

}