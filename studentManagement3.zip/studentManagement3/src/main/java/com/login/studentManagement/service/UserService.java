package com.login.studentManagement.service;

import com.login.studentManagement.modal.UserDtls;

public interface UserService {

	public UserDtls createUser(UserDtls user);

	public boolean checkEmail(String email);

	UserDtls createadminUser(UserDtls user);

}