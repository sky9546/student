package com.login.studentManagement.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.HttpServletBean;

import com.login.studentManagement.modal.SubcriptionDetails;
import com.login.studentManagement.modal.UserDtls;
import com.login.studentManagement.modal.courseDetails;
import com.login.studentManagement.repository.CourseRepository;
import com.login.studentManagement.repository.SubcriptionRepository;
import com.login.studentManagement.repository.UserRepository;
import com.login.studentManagement.service.CourseService;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserRepository userRepo;
	@Autowired
	CourseService courseservice ;
	
	@Autowired
	CourseRepository courserepository ;
	
	@Autowired
	SubcriptionRepository subsrepo ;

	@ModelAttribute
	private void userDetails(Model m, Principal p) {
		String email = p.getName();
		UserDtls user = userRepo.findByEmail(email);

		m.addAttribute("user", user);

	}

	@GetMapping("/")
	public String home(Model model) {
	System.out.println(courseservice.getCourse().size());
		model.addAttribute("signedin", true);
		model.addAttribute("isadmin", false);
		
		model.addAttribute("courseList", courseservice.getCourse());
		
		return "user/home";
	}
	
	@GetMapping("/course/{courseID}")
	public String subscribeCourse(@PathVariable(value="courseID" ) String courseid , Model model,HttpSession session) {
		
		UserDtls user = new UserDtls();
		
		user = (UserDtls) model.getAttribute("user") ;
		if(user!=null) {
			model.addAttribute("signedin", true);
			model.addAttribute("isadmin", false);
		}
		SubcriptionDetails subs = new SubcriptionDetails();
		subs.setCourse_id(Integer.parseInt(courseid));
		subs.setUser_id(user.getId());
		subsrepo.save(subs);
		
		List<SubcriptionDetails> subslist= new ArrayList<SubcriptionDetails>();
		subslist.addAll(subsrepo.findByuser_id(user.getId()));
		Set<Integer> course_ids = new HashSet<>();
		for(SubcriptionDetails coursesubs:subslist ) {
			course_ids.add(coursesubs.getCourse_id());
			
		}
		
		List<courseDetails> subedcourses = new ArrayList<courseDetails>();
		subedcourses =	courserepository.findAllById(course_ids);
		
		model.addAttribute("subedcourses", subedcourses);
		System.out.println(subedcourses.toString());
		
		System.out.println(course_ids.toString());
		
		System.out.println(subslist.size());
//		System.out.print(courseid);
//		System.out.print(user.getId());
		
		
		return "user/manageSubcriptions" ;
	}
	
	@GetMapping("/manageSubcriptions")
	public String manageCourse(Model model) {
	UserDtls user = new UserDtls();
		
		user = (UserDtls) model.getAttribute("user") ;
		if(user!=null) {
			model.addAttribute("signedin", true);
			model.addAttribute("isadmin", false);
		}
		List<SubcriptionDetails> subslist= new ArrayList<SubcriptionDetails>();
		subslist.addAll(subsrepo.findByuser_id(user.getId()));
		Set<Integer> course_ids = new HashSet<>();
		for(SubcriptionDetails coursesubs:subslist ) {
			course_ids.add(coursesubs.getCourse_id());
			
		}
		
		List<courseDetails> subedcourses = new ArrayList<courseDetails>();
		subedcourses =	courserepository.findAllById(course_ids);
		
		model.addAttribute("subedcourses", subedcourses);
		System.out.println(subedcourses.toString());
		
		System.out.println(course_ids.toString());
		
		System.out.println(subslist.size());
		return "user/manageSubcriptions" ;
		
	}
	
	
	
	@GetMapping("/course/delete/{courseID}")
	public String unsubscribeCourse(@PathVariable(value="courseID" ) String courseid , Model model,HttpSession session) {
		
	UserDtls user = new UserDtls();
		
		user = (UserDtls) model.getAttribute("user") ;
		if(user!=null) {
			model.addAttribute("signedin", true);
			model.addAttribute("isadmin", false);
		}
		
		subsrepo.deleteBycourse_id(Integer.parseInt(courseid));
		
		List<SubcriptionDetails> subslist= new ArrayList<SubcriptionDetails>();
		subslist.addAll(subsrepo.findByuser_id(user.getId()));
		Set<Integer> course_ids = new HashSet<>();
		for(SubcriptionDetails coursesubs:subslist ) {
			course_ids.add(coursesubs.getCourse_id());
			
		}
		
		List<courseDetails> subedcourses = new ArrayList<courseDetails>();
		subedcourses =	courserepository.findAllById(course_ids);
		
		model.addAttribute("subedcourses", subedcourses);
		System.out.println(subedcourses.toString());
		
		System.out.println(course_ids.toString());
		
		System.out.println(subslist.size());
//		System.out.print(courseid);
//		System.out.print(user.getId());
		
		
		return "user/manageSubcriptions" ;
		
		
	}
	
	
	
	
	
	

}